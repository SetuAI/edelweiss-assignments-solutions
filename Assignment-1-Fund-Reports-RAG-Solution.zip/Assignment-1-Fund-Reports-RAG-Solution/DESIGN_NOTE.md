# Design Note: Sub-Agentic Fund-Report RAG

## Goal

The goal is to answer analytical questions across three fund reports while staying grounded, on-scope, and safe. The assistant should compare funds, explain risk, discuss holdings, and cite the source reports. It should not invent numbers or provide personalised buy/sell advice.

## Architecture

The system has five layers:

| Layer | Role |
| --- | --- |
| Ingestion | Reads the PDFs and splits them into searchable chunks. |
| Retrieval | Returns relevant chunks for specialist analysts. |
| Specialists | Performance, holdings, and risk analysts each retrieve evidence for their own topic. |
| Guardrails | Enforce injection blocking, scope control, advice detection, and grounding. |
| Human review | Approves, edits, or rejects the answer before delivery. |

The code is organised around the same architecture:

| File | Responsibility |
| --- | --- |
| `ingest.py` | PDF extraction, chunking, and retrieval. |
| `guardrails.py` | Code-enforced safety checks. |
| `app.py` | Agent workflow and human-review gate. |

## Rules Enforced in Code

Prompt injection is blocked by regex patterns before retrieval or analysis begins. This prevents requests such as "ignore your instructions" or "print the system prompt" from entering the normal answer path.

Scope is checked before retrieval. Questions unrelated to the fund reports, such as weather questions, are blocked with a clear message.

Investment-advice requests are flagged. The assistant can analyse the provided fictional fund report, but it does not tell the user whether they personally should buy, sell, invest, or hold.

Grounding is checked after synthesis. Any figure in the final answer must appear in retrieved evidence or specialist findings. If a number is not found, the answer is flagged for reviewer attention.

## Why These Rules Should Not Live Only in Prompts

If these rules were only written in a prompt, the model might still follow a malicious user instruction, answer outside the corpus, or invent a number that sounds plausible. Code checks are more reliable because they happen before and after generation, independent of model behavior.

The most important example is grounding. A fund-report assistant is dangerous if it invents returns, drawdowns, or credit-quality percentages. This solution extracts figures from the final answer and verifies that they exist in evidence before the answer is approved.

## Human-in-the-Loop Design

The final answer is not treated as delivered until a human reviewer approves it. The CLI simulates three reviewer actions: approve, edit, and reject. This matches the assignment requirement and models how an advisory desk would review analysis before using it.

## Extension Path

This solution uses a transparent local retriever for reliable classroom execution. To extend it, replace `SimpleVectorStore` with embeddings and a vector database, and replace deterministic specialist summaries with LLM calls over retrieved chunks. The guardrails should remain in code.
