"""Guardrails for the fund-report RAG assistant.

The assignment needs four kinds of protection:

1. Prompt-injection blocking.
2. Topic/scope checking.
3. Investment-advice handling.
4. Grounding checks so final answers do not invent numbers.

Hard rules are implemented in code because prompt instructions alone are not
reliable enforcement boundaries.
"""

from __future__ import annotations

import re
from typing import Iterable


INJECTION_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in [
        r"ignore (all |the )?(previous|prior|above) instructions",
        r"disregard .* instructions",
        r"reveal your (system )?(prompt|instructions)",
        r"print the system prompt",
        r"show the system prompt",
    ]
]

ADVICE_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in [
        r"\bshould i (buy|sell|invest|hold)\b",
        r"\bshould we (buy|sell|invest|hold)\b",
        r"\bis (it|this) a good (buy|investment)\b",
        r"\bhow much should i invest\b",
        r"\bwill .*(price|nav).*(go up|rise|fall|crash)\b",
    ]
]

TOPIC_KEYWORDS = {
    "aditya",
    "allocation",
    "aum",
    "balanced",
    "benchmark",
    "bond",
    "buy",
    "corporate",
    "credit",
    "debt",
    "duration",
    "equity",
    "expense",
    "fees",
    "fund",
    "funds",
    "holdings",
    "interest-rate",
    "investment",
    "large cap",
    "meridian",
    "mutual",
    "performance",
    "portfolio",
    "return",
    "returns",
    "risk",
    "sell",
    "sharpe",
    "volatility",
    "zenith",
}


def check_injection(query: str) -> str | None:
    """Block requests that try to override the assistant's instructions."""

    for pattern in INJECTION_PATTERNS:
        if pattern.search(query):
            return "possible prompt-injection attempt"
    return None


def check_investment_advice(query: str) -> bool:
    """Detect personalised buy/sell/invest/hold requests."""

    return any(pattern.search(query) for pattern in ADVICE_PATTERNS)


def check_topic(query: str) -> tuple[bool, str]:
    """Keep the assistant focused on the provided fund reports."""

    q = query.lower()
    if any(keyword in q for keyword in TOPIC_KEYWORDS):
        return True, ""
    return False, "outside the scope of the provided fund reports"


def strip_reasoning(text: str) -> str:
    """Remove local-model reasoning tags if they appear in generated text."""

    return re.sub(r"<think>.*?</think>", " ", text, flags=re.DOTALL | re.IGNORECASE).strip()


def _normalise_number(number: str) -> str:
    """Normalise a displayed figure before checking it against evidence."""

    return number.replace(",", "").strip()


def _answer_numbers(answer: str) -> list[str]:
    """Extract figures from answer text while ignoring list markers."""

    numbers: list[str] = []
    for line in answer.splitlines():
        line_without_marker = re.sub(r"^\s*\d+\.\s+", "", line)
        numbers.extend(re.findall(r"\d[\d,]*\.?\d*", line_without_marker))
    return [_normalise_number(number) for number in numbers]


def check_grounding(answer: str, evidence_parts: Iterable[str]) -> tuple[bool, str]:
    """Check that every figure in the answer appears in retrieved evidence.

    This is intentionally conservative: if the answer introduces a number that
    was not retrieved, the human reviewer gets a flag.
    """

    evidence = "\n".join(evidence_parts).replace(",", "")
    missing = sorted({number for number in _answer_numbers(answer) if number not in evidence})
    if missing:
        return False, f"figures not found in evidence: {missing}"
    return True, ""


def disclaimer() -> str:
    """Standard non-advice language attached to advice-style questions."""

    return (
        "This is analysis from the provided fictional reports, not personalised "
        "investment advice."
    )
