"""PDF ingestion and retrieval for Assignment 1.

The assignment asks for RAG over three fund reports. This implementation keeps
the retrieval layer dependency-light so students can run it immediately:

1. Extract text from each PDF with `pypdf`.
2. Split the text into overlapping chunks.
3. Rank chunks with a simple lexical similarity score.

In production, the same public functions can be backed by OpenAI embeddings,
Chroma, FAISS, or another vector store without changing the agent workflow.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path

from pypdf import PdfReader


DATA_DIR = Path(__file__).parent / "data"

FUND_NAMES = {
    "aditya_large_cap_equity_fund_report": "Aditya Large Cap Equity Fund",
    "meridian_corporate_bond_fund_report": "Meridian Corporate Bond Fund",
    "zenith_balanced_advantage_fund_report": "Zenith Balanced Advantage Fund",
}

STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "by",
    "for",
    "from",
    "fund",
    "how",
    "in",
    "is",
    "it",
    "of",
    "on",
    "or",
    "the",
    "their",
    "this",
    "to",
    "with",
}


@dataclass(frozen=True)
class Document:
    """A chunk of evidence with source metadata."""

    page_content: str
    source: str
    fund_name: str
    chunk_id: int


def _clean_text(text: str) -> str:
    """Normalise whitespace while preserving table values and sentences."""

    return re.sub(r"\s+", " ", text).strip()


def _tokens(text: str) -> set[str]:
    """Tokenise text for a transparent classroom-friendly retriever."""

    words = re.findall(r"[a-zA-Z][a-zA-Z0-9+\-]*|\d+\.?\d*", text.lower())
    return {word for word in words if word not in STOPWORDS and len(word) > 1}


def _split_text(text: str, chunk_size: int = 1100, overlap: int = 180) -> list[str]:
    """Split long report text into overlapping chunks.

    Overlap keeps table headers and nearby values together, which is useful for
    fund reports where a metric label and its number may sit on adjacent lines.
    """

    clean = _clean_text(text)
    chunks: list[str] = []
    start = 0
    while start < len(clean):
        end = min(start + chunk_size, len(clean))
        chunks.append(clean[start:end])
        if end == len(clean):
            break
        start = max(0, end - overlap)
    return chunks


def read_pdf(pdf_path: Path) -> str:
    """Extract all text from a PDF report."""

    reader = PdfReader(str(pdf_path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def load_documents(data_dir: Path = DATA_DIR) -> list[Document]:
    """Read every PDF and return searchable evidence chunks."""

    docs: list[Document] = []
    for pdf_path in sorted(data_dir.glob("*.pdf")):
        source = pdf_path.stem
        fund_name = FUND_NAMES.get(source, source.replace("_", " ").title())
        for chunk_id, chunk in enumerate(_split_text(read_pdf(pdf_path)), start=1):
            docs.append(
                Document(
                    page_content=chunk,
                    source=source,
                    fund_name=fund_name,
                    chunk_id=chunk_id,
                )
            )
    return docs


class SimpleVectorStore:
    """Small in-memory retriever with an embedding-like public interface."""

    def __init__(self, documents: list[Document]) -> None:
        self.documents = documents
        self._doc_tokens = [(_tokens(doc.page_content), doc) for doc in documents]

    def similarity_search(
        self,
        query: str,
        *,
        k: int = 4,
        source_filter: set[str] | None = None,
    ) -> list[Document]:
        """Return the top-k chunks ranked by token overlap and coverage."""

        query_tokens = _tokens(query)
        scored: list[tuple[float, Document]] = []
        for doc_tokens, doc in self._doc_tokens:
            if source_filter and doc.source not in source_filter:
                continue
            overlap = query_tokens & doc_tokens
            if not overlap:
                continue
            # A tiny TF-style score: reward overlap, but avoid always selecting
            # the longest chunk just because it contains more words.
            score = len(overlap) / math.sqrt(max(len(doc_tokens), 1))
            scored.append((score, doc))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [doc for _, doc in scored[:k]]


def build_store(data_dir: Path = DATA_DIR) -> SimpleVectorStore:
    """Build the searchable in-memory store."""

    return SimpleVectorStore(load_documents(data_dir))


def make_retriever(store: SimpleVectorStore):
    """Return a specialist-friendly retrieval function."""

    def retrieve(
        query: str,
        *,
        k: int = 4,
        funds: set[str] | None = None,
    ) -> list[Document]:
        return store.similarity_search(query, k=k, source_filter=funds)

    return retrieve


if __name__ == "__main__":
    docs = load_documents()
    print(f"Loaded {len(docs)} chunks from {len(FUND_NAMES)} fund reports.")
    for doc in docs[:3]:
        print(f"- {doc.fund_name} / chunk {doc.chunk_id}: {doc.page_content[:90]}...")
