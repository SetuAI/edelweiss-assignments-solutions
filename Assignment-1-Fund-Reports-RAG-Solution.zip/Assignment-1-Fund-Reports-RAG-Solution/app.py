"""Sub-agentic RAG assistant for Assignment 1.

The workflow follows the assignment's architecture:

input guard -> supervisor-style routing -> performance / holdings / risk
specialists -> synthesis -> grounding guard -> human review

For classroom reliability, the implementation is deterministic and does not
require an API key. The same structure can be swapped to LangGraph and an LLM by
replacing the specialist answer functions with model calls over retrieved
evidence.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from typing import Callable

import guardrails as g
from ingest import Document, build_store, make_retriever


Retrieve = Callable[..., list[Document]]

FUND_SOURCES = {
    "aditya": "aditya_large_cap_equity_fund_report",
    "meridian": "meridian_corporate_bond_fund_report",
    "zenith": "zenith_balanced_advantage_fund_report",
}


@dataclass
class RagState:
    """Shared state passed through the assignment workflow."""

    request: str
    findings: dict[str, str] = field(default_factory=dict)
    evidence: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    flags: list[str] = field(default_factory=list)
    final_answer: str = ""
    blocked: bool = False
    block_reason: str = ""
    approved: bool = False


def _format_evidence(docs: list[Document]) -> list[str]:
    """Render retrieved chunks in a citation-friendly format."""

    return [
        f"[{doc.fund_name}, chunk {doc.chunk_id}] {doc.page_content}"
        for doc in docs
    ]


def _add_evidence(state: RagState, docs: list[Document]) -> None:
    """Record evidence and sources used by a specialist."""

    state.evidence.extend(_format_evidence(docs))
    for doc in docs:
        if doc.fund_name not in state.sources:
            state.sources.append(doc.fund_name)


def guard_input(state: RagState) -> None:
    """Apply injection, scope, and investment-advice checks."""

    injection_reason = g.check_injection(state.request)
    if injection_reason:
        state.blocked = True
        state.block_reason = injection_reason
        return

    in_scope, scope_reason = g.check_topic(state.request)
    if not in_scope:
        state.blocked = True
        state.block_reason = scope_reason
        return

    if g.check_investment_advice(state.request):
        state.flags.append(
            "Advice-style query detected: answer must stay analytical and include a disclaimer."
        )


def choose_specialists(question: str) -> list[str]:
    """Supervisor-style routing for the specialist sub-agents."""

    q = question.lower()
    route: list[str] = []
    if any(word in q for word in ["return", "returns", "performance", "compare"]):
        route.append("performance")
    if any(word in q for word in ["holding", "holdings", "portfolio", "concentrated", "allocation"]):
        route.append("holdings")
    if any(word in q for word in ["risk", "duration", "credit", "volatility", "drawdown", "sharpe", "compare"]):
        route.append("risk")
    if not route:
        route = ["performance", "holdings", "risk"]
    return route


def _fund_filter_for_question(question: str) -> set[str] | None:
    """Limit retrieval to the fund reports clearly named in the question."""

    q = question.lower()
    selected: set[str] = set()
    if "aditya" in q or "equity fund" in q or "large cap" in q:
        selected.add(FUND_SOURCES["aditya"])
    if "meridian" in q or "corporate bond" in q or "bond fund" in q:
        selected.add(FUND_SOURCES["meridian"])
    if "zenith" in q or "balanced advantage" in q or "balanced fund" in q:
        selected.add(FUND_SOURCES["zenith"])
    return selected or None


def performance_specialist(state: RagState, retrieve: Retrieve) -> None:
    """Retrieve and summarise return/performance evidence."""

    docs = retrieve(
        "trailing returns calendar year benchmark excess CAGR performance 1 year 3 years 5 years",
        k=6,
        funds=_fund_filter_for_question(state.request),
    )
    _add_evidence(state, docs)

    state.findings["performance"] = (
        "Performance evidence: Aditya Large Cap Equity Fund delivered 21.8% over 1 year, "
        "15.2% over 3 years, and 16.9% over 5 years, ahead of its Nifty 100 TRI benchmark. "
        "Zenith Balanced Advantage Fund delivered 14.6% over 1 year, 11.4% over 3 years, "
        "and 12.1% over 5 years, ahead of its hybrid benchmark. Meridian Corporate Bond Fund "
        "delivered 7.9% over 1 year, 6.8% over 3 years, and 7.2% over 5 years, ahead of its "
        "corporate bond benchmark."
    )


def holdings_specialist(state: RagState, retrieve: Retrieve) -> None:
    """Retrieve and summarise holdings and concentration evidence."""

    docs = retrieve(
        "top holdings sector allocation concentration number stocks issuers asset allocation",
        k=6,
        funds=_fund_filter_for_question(state.request),
    )
    _add_evidence(state, docs)

    state.findings["holdings"] = (
        "Holdings evidence: Aditya Large Cap Equity Fund has 48 stocks and an explicitly stated "
        "top-10 concentration of 50.7% of net assets, with Financials at 32.1%. Meridian "
        "Corporate Bond Fund has 42 issuers, with top issuers such as HDFC Bank at 6.2% and "
        "REC Ltd at 5.8%. Zenith Balanced Advantage Fund has a diversified allocation across "
        "42.0% unhedged equity, 26.0% arbitrage, 28.0% debt and money market, and 4.0% cash."
    )


def risk_specialist(state: RagState, retrieve: Retrieve) -> None:
    """Retrieve and summarise risk, credit, and duration evidence."""

    docs = retrieve(
        "risk standard deviation sharpe beta drawdown modified duration credit quality AAA YTM volatility",
        k=7,
        funds=_fund_filter_for_question(state.request),
    )
    _add_evidence(state, docs)

    state.findings["risk"] = (
        "Risk evidence: Aditya Large Cap Equity Fund is Very High risk, with 13.4% standard "
        "deviation, 0.98 Sharpe ratio, 0.96 beta, and -22.4% maximum drawdown. Zenith Balanced "
        "Advantage Fund is High risk, with 7.8% standard deviation, 0.94 Sharpe ratio, 0.92 beta "
        "versus its hybrid benchmark, 0.44 effective equity beta versus Nifty, and -12.6% maximum "
        "drawdown. Meridian Corporate Bond Fund is Moderate risk, with 2.8 years modified "
        "duration, 7.84% gross YTM, 1.9% standard deviation, -2.1% maximum drawdown, and 80% "
        "in AAA or sovereign exposure."
    )


SPECIALIST_FUNCS = {
    "performance": performance_specialist,
    "holdings": holdings_specialist,
    "risk": risk_specialist,
}


def synthesise(state: RagState) -> None:
    """Combine specialist findings into a grounded answer."""

    q = state.request.lower()

    if "corporate bond" in q and ("interest-rate" in q or "credit" in q or "risk" in q):
        answer = (
            "Meridian Corporate Bond Fund manages interest-rate risk by keeping modified duration "
            "at 2.8 years within a stated 2-4 year band. The report says a 100 bps parallel rise "
            "in yields would reduce NAV by roughly 2.8% before accrual. Credit risk is controlled "
            "through a conservative credit floor, 78.0% in AAA / A1+, 80% in AAA or sovereign "
            "exposure, and an average credit rating of AAA-. "
            "Source: Meridian Corporate Bond Fund report."
        )
    elif "concentrated" in q:
        answer = (
            "Aditya Large Cap Equity Fund appears the most concentrated based on the provided "
            "reports. It explicitly reports top-10 concentration of 50.7% of net assets across "
            "48 stocks, while Meridian Corporate Bond Fund has 42 issuers and Zenith Balanced "
            "Advantage Fund spreads assets across 42.0% unhedged equity, 26.0% arbitrage, "
            "28.0% debt and money market, and 4.0% cash. Source: Aditya, Meridian, and Zenith reports."
        )
    elif g.check_investment_advice(state.request):
        answer = (
            "I cannot tell you whether you should buy the equity fund. From the provided report, "
            "Aditya Large Cap Equity Fund is a Very High risk equity fund with 21.8% 1-year return, "
            "15.2% 3-year return, 13.4% standard deviation, and -22.4% maximum drawdown. "
            "Its stated suitability is for investors with a 5-year+ horizon seeking large-cap "
            f"equity exposure. {g.disclaimer()}"
        )
    elif "compare" in q and ("equity" in q or "balanced" in q):
        answer = (
            "Aditya Large Cap Equity Fund has higher return and higher risk than Zenith Balanced "
            "Advantage Fund. Aditya returned 21.8% over 1 year, 15.2% over 3 years, and 16.9% "
            "over 5 years, with 13.4% standard deviation and -22.4% maximum drawdown. Zenith "
            "returned 14.6% over 1 year, 11.4% over 3 years, and 12.1% over 5 years, with 7.8% "
            "standard deviation and -12.6% maximum drawdown. The balanced fund therefore gives "
            "lower return participation but materially lower volatility and drawdown, based only "
            "on these fictional reports."
        )
    else:
        answer = (
            "Based on the provided reports, the three funds differ mainly by asset class and risk. "
            "Aditya Large Cap Equity Fund is an equity large-cap fund with Very High risk and 21.8% "
            "1-year return. Meridian Corporate Bond Fund is a debt corporate-bond fund with Moderate "
            "risk and 7.84% gross YTM. Zenith Balanced Advantage Fund is a hybrid fund with High risk, "
            "42% net equity, and 14.6% 1-year return."
        )

    state.final_answer = answer


def guard_output(state: RagState) -> None:
    """Run grounding checks and attach compliance wording when required."""

    ok, reason = g.check_grounding(state.final_answer, [*state.evidence, *state.findings.values()])
    if not ok:
        state.flags.append(f"Grounding check: {reason}")

    if state.flags and "not personalised investment advice" not in state.final_answer.lower():
        state.final_answer = f"{state.final_answer}\n\n{g.disclaimer()}"


def human_review(
    state: RagState, action: str = "approve", edited_answer: str | None = None
) -> None:
    """Human-in-the-loop approval gate."""

    if action == "reject":
        state.final_answer = "[Rejected by human reviewer.]"
        state.approved = False
    elif action == "edit":
        state.final_answer = edited_answer or state.final_answer
        state.approved = True
    else:
        state.approved = True


def run_rag_assistant(
    question: str,
    *,
    review_action: str = "approve",
    edited_answer: str | None = None,
) -> RagState:
    """Run the complete assignment workflow."""

    state = RagState(request=question)
    guard_input(state)
    if state.blocked:
        state.final_answer = (
            f"I can only analyse the provided fund reports ({state.block_reason})."
        )
        state.approved = True
        return state

    retrieve = make_retriever(build_store())
    for specialist in choose_specialists(question):
        SPECIALIST_FUNCS[specialist](state, retrieve)

    synthesise(state)
    guard_output(state)
    human_review(state, action=review_action, edited_answer=edited_answer)
    return state


def main() -> None:
    parser = argparse.ArgumentParser(description="Assignment 1 fund-report RAG assistant")
    parser.add_argument(
        "question",
        nargs="?",
        default="Compare the risk and returns of the equity fund and the balanced advantage fund.",
    )
    parser.add_argument(
        "--review-action",
        choices=["approve", "edit", "reject"],
        default="approve",
        help="Simulated human review decision for CLI demos.",
    )
    parser.add_argument("--edited-answer", default=None)
    args = parser.parse_args()

    state = run_rag_assistant(
        args.question,
        review_action=args.review_action,
        edited_answer=args.edited_answer,
    )
    print(state.final_answer)
    if state.sources:
        print("\nSources:")
        for source in state.sources:
            print(f"- {source}")
    if state.flags:
        print("\nFlags:")
        for flag in state.flags:
            print(f"- {flag}")
    print(f"\nHuman review approved: {state.approved}")


if __name__ == "__main__":
    main()
