# Assignment 1 — Sub-Agentic RAG over Fund Reports (Guardrails + Human-in-the-Loop)

Build a supervised multi-agent RAG assistant that answers analytical questions across three
mutual-fund reports, safely and with grounded answers a human approves.

## What's in this folder
- `Assignment-1-Reference-Guide.pdf` — the complete assignment: objective, scenario, architecture,
  full step-by-step build with working code, test questions, rubric, and submission checklist.
- `data/` — the corpus (three fictional but internally-consistent fund reports):
  - `aditya_large_cap_equity_fund_report.pdf`   (Equity — Large Cap)
  - `meridian_corporate_bond_fund_report.pdf`   (Debt — Corporate Bond)
  - `zenith_balanced_advantage_fund_report.pdf` (Hybrid — Balanced Advantage)

## How to start
1. Read `Assignment-1-Reference-Guide.pdf` end to end.
2. Set up the project as described (LangGraph + langchain-openai + pypdf; `OPENAI_API_KEY`).
3. Build ingestion -> retrieving sub-agents -> supervisor -> guardrails -> human review, using the
   reference code as your guide.
4. Validate against the six test questions and complete the submission checklist.

All data is fictional and for training only. Nothing here is investment advice.
