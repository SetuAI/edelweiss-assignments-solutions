# Assignment 2 Solution: Sub-Agentic Incident Analysis over Server Logs

This project is the completed solution for the FundFlow MCP server log assignment. It builds an SRE-style copilot that diagnoses a distributed incident across the NAV service and order service logs, redacts PII before analysis, and sends the final RCA through a human-review gate.

All data in this project is fictional and for AI-engineering training only.

## What This Solution Contains

| File | Purpose |
| --- | --- |
| `fundflow_logs_mcp.py` | MCP server exposing the two logs through callable tools. |
| `guardrails_logs.py` | PII redaction, prompt-injection blocking, scope checking, and final output safety. |
| `app.py` | Sub-agentic incident copilot: input guard, specialists, supervisor-style orchestration, RCA synthesis, and human review. |
| `run_assignment_tests.py` | Offline verification script for MCP tool logic, PII redaction, guardrails, RCA facts, and review handling. |
| `requirements.txt` | Python dependencies for the full MCP/LangGraph environment. |
| `DESIGN_NOTE.md` | One-page design note explaining the architecture and guardrail placement. |
| `TRANSCRIPT.md` | Transcript of the six assignment test questions and expected behavior. |
| `data/` | Provided NAV-service and order-service logs. |
| `Assignment-2-Reference-Guide.pdf` | Original assignment reference guide. |

## Incident Summary

At 14:29 on 31 Mar 2026, the NAV service experienced elevated latency and timeout from the primary price feed, BharatData. A corrupt negative constituent price was also present. The NAV validator rejected the affected scheme, `FF-LC-EQ-001`, and the NAV publisher held publication.

The order service later attempted to price same-day redemptions and switches for the same scheme. Because the NAV was unavailable, those orders failed with `NAV_UNAVAILABLE`, were queued for reprocessing, and triggered a SEV2 alert. The shared correlation id is `corr-77f31a`.

## Architecture

```mermaid
flowchart TD
    A["User question"] --> B["Input guard"]
    B --> C["Supervisor-style router"]
    C --> D["NAV analyst"]
    C --> E["Order analyst"]
    C --> F["Correlation analyst"]
    D --> G["RCA synthesis"]
    E --> G
    F --> G
    G --> H["Output guard"]
    H --> I["Human review"]
```

The MCP server provides the log tools. The agent does not read log files directly during analysis; it calls tools through a guarded boundary. That boundary redacts PII immediately, before any model prompt, analyst logic, transcript, or final answer can use raw log output.

## Setup

Create and activate a virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

For a full LLM-backed extension, also set:

```bash
export OPENAI_API_KEY="your_key_here"
```

This submitted solution can run its local tests without external APIs or optional MCP packages. That makes it easy to demonstrate in classrooms where students may not yet have keys configured.

## Run the MCP Server

Start the server over stdio:

```bash
python fundflow_logs_mcp.py
```

Or inspect it with the MCP CLI:

```bash
mcp dev fundflow_logs_mcp.py
```

Key tools exposed by the server:

| Tool | What it does |
| --- | --- |
| `list_services()` | Lists `nav-service` and `order-service`. |
| `search_logs(service, contains="", level="")` | Searches log lines by substring and/or level. |
| `get_errors(service)` | Returns WARN and ERROR lines. |
| `trace_correlation(correlation_id)` | Returns all cross-service lines for a correlation id in time order. |
| `get_timeline(correlation_id)` | Returns a compact timeline for reporting. |

## Run the Copilot

Offline deterministic run:

```bash
python app.py "Summarise the incident and its root cause."
```

Run through the MCP backend after installing the MCP dependencies:

```bash
python app.py --mcp "Trace correlation id corr-77f31a across services."
```

Simulate human review decisions:

```bash
python app.py "Summarise the incident and its root cause." --review-action approve
python app.py "Summarise the incident and its root cause." --review-action reject
python app.py "Summarise the incident and its root cause." --review-action edit --edited-answer "Approved with reviewer edits."
```

## Run Verification

```bash
python -m py_compile fundflow_logs_mcp.py guardrails_logs.py app.py run_assignment_tests.py
python run_assignment_tests.py
```

Expected result:

```text
All assignment checks passed.
```

## How the Solution Works End to End

1. The user asks an incident-related question.
2. `guard_input()` blocks prompt-injection attempts and questions outside the FundFlow incident-log scope.
3. The tool backend loads either the MCP tools or direct local tool functions for offline testing.
4. `SafeToolbox` calls the selected tool and immediately applies `guardrails_logs.redact_output()`.
5. The NAV analyst identifies the upstream root cause: BharatData latency, timeout, open circuit breaker, stale prices, negative price, and held NAV publication.
6. The order analyst identifies downstream symptoms: `NAV_UNAVAILABLE`, held orders, 41% 5xx rate, p95 latency of 8140 ms, and the SEV2 alert.
7. The correlation analyst traces `corr-77f31a` across both services to connect cause and symptom.
8. The synthesiser writes a concise RCA using only the specialist findings.
9. `guard_output()` redacts the final answer again as a safety net.
10. `human_review()` approves, edits, or rejects the final RCA.

## Final RCA

FundFlow experienced a SEV2 incident for `FF-LC-EQ-001` redemptions on 31 Mar 2026. Same-day redemption and switch orders were delayed because the order service could not obtain a valid NAV.

The root cause was in the NAV service. The primary price feed, BharatData, became slow, timed out, and returned a corrupt negative constituent price. The NAV validator rejected the affected scheme because of stale prices and the negative price, so the NAV publisher held publication and downstream services saw `NAV_UNAVAILABLE`.

The impact was 9 held redemption/switch orders, a 41% 5xx rate on `/orders/redeem`, and p95 latency of 8140 ms. The order-service incident lasted about 13 minutes. Logs state that 0 orders were lost and 0 duplicate submissions occurred.

Recommended fixes are to raise a vendor ticket with BharatData, add a negative-price pre-filter before NAV validation, review the 8000 ms timeout and failover policy, and add correlation-id dashboards joining NAV publish holds to order-service failures.
