# Design Note: FundFlow Incident Copilot

## Objective

The assignment asks for an SRE-style assistant that can diagnose a distributed incident across two service logs. The solution uses an MCP server to expose log data as tools, specialist analysts to inspect each service, a correlation analyst to connect cause and symptom, and a human-review gate before the RCA is considered approved.

## Core Design

The MCP server is implemented in `fundflow_logs_mcp.py`. It exposes five tools:

| Tool | Reason |
| --- | --- |
| `list_services` | Lets the agent discover available logs. |
| `search_logs` | Supports targeted search by substring and log level. |
| `get_errors` | Gives the fastest path to WARN and ERROR lines. |
| `trace_correlation` | Connects NAV and order events through `corr-77f31a`. |
| `get_timeline` | Converts correlated lines into report-friendly event rows. |

The agent workflow is implemented in `app.py`. The NAV analyst identifies the upstream root cause. The order analyst identifies user-facing symptoms. The correlation analyst links both services by correlation id. The synthesis step writes the RCA only from those findings.

## Why PII Redaction Runs on Tool Output

The order-service log contains a DEBUG request dump with PAN, folio, email, and investor name. If redaction were only written as a prompt instruction, the raw PII would still enter the model context. A model could quote it by mistake, include it in hidden reasoning, pass it to another tool, or leak it through a transcript.

This solution redacts at the tool boundary through `SafeToolbox`. Every tool call returns raw data to the backend, then `guardrails_logs.redact_output()` immediately replaces sensitive values before any analyst logic or model-facing text can consume it.

The redaction covers:

| PII type | Example pattern | Replacement |
| --- | --- | --- |
| PAN | `AKLPS4321Q` | `[PAN_REDACTED]` |
| Email | `r.sharma@example.com` | `[EMAIL_REDACTED]` |
| Unmasked folio | `FF88213921` | `[FOLIO_REDACTED]` |
| Investor name field | `name='R. Sharma'` | `name='[NAME_REDACTED]'` |

Masked folios such as `FF****2437` remain visible because they are already safe operational identifiers.

## Human-in-the-Loop Review

The RCA is not treated as final until a reviewer decision is applied. The CLI supports `approve`, `edit`, and `reject`. This models an on-call incident commander reviewing the draft before it is shared with a wider audience.

## Main Tradeoff

The project includes a deterministic local path so it can be tested without API keys or optional packages. In a full production build, the specialist functions can be replaced with LLM calls over the same redacted tool outputs. The important boundary remains unchanged: raw log text must be cleaned before it reaches the model.
