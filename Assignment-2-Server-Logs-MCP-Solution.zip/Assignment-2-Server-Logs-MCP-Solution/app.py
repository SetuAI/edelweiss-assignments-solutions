"""Sub-agentic SRE copilot for the FundFlow incident assignment.

The workflow mirrors the reference architecture:

input guard -> supervisor -> NAV analyst -> order analyst -> correlation analyst
-> synthesis -> output guard -> human review

The code can use the MCP server when `langchain-mcp-adapters` is installed. For
teaching and automated verification, it also includes a direct local-tool
backend with the same interface. The guardrail wrapper is the same in both
paths, so PII is redacted before analyst logic or an LLM can consume tool data.
"""

from __future__ import annotations

import argparse
import asyncio
import re
from dataclasses import dataclass, field
from typing import Any, Protocol

import guardrails_logs as gl


INCIDENT_CORRELATION_ID = "corr-77f31a"


class ToolBackend(Protocol):
    """Minimal async interface used by every specialist."""

    async def load(self) -> None:
        """Prepare the backend before the first tool call."""

    async def call(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """Call one log tool and return its raw result."""


class DirectLogBackend:
    """Local backend used for tests and demos without MCP dependencies."""

    async def load(self) -> None:
        import fundflow_logs_mcp as logs

        self.logs = logs

    async def call(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        tool = getattr(self.logs, tool_name)
        return tool(**arguments)


class MCPLogBackend:
    """MCP backend that spawns `fundflow_logs_mcp.py` over stdio."""

    def __init__(self, server_script: str = "fundflow_logs_mcp.py") -> None:
        self.server_script = server_script
        self.tools: dict[str, Any] = {}

    async def load(self) -> None:
        from langchain_mcp_adapters.client import MultiServerMCPClient

        client = MultiServerMCPClient(
            {
                "fundflow-logs": {
                    "command": "python",
                    "args": [self.server_script],
                    "transport": "stdio",
                }
            }
        )
        self.tools = {tool.name: tool for tool in await client.get_tools()}

    async def call(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        return await self.tools[tool_name].ainvoke(arguments)


class SafeToolbox:
    """Guarded tool boundary used by all specialists.

    Raw tool output is immediately redacted here. No analyst function, model
    prompt, transcript, or final report receives the unredacted tool response.
    """

    def __init__(self, backend: ToolBackend) -> None:
        self.backend = backend

    async def load(self) -> None:
        await self.backend.load()

    async def call(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        raw = await self.backend.call(tool_name, arguments)
        safe = gl.redact_output(raw)
        gl.assert_no_pii(safe)
        return safe


@dataclass
class IncidentState:
    """Shared state passed through the sub-agent workflow."""

    request: str
    findings: dict[str, str] = field(default_factory=dict)
    final_answer: str = ""
    blocked: bool = False
    block_reason: str = ""
    approved: bool = False


def _first_time(lines: list[str], keyword: str) -> str:
    """Find the first timestamped line containing a keyword."""

    for line in lines:
        if keyword.lower() in line.lower():
            return line[:23]
    return "not found"


def _first_timeline_time(rows: list[dict[str, str]], keyword: str, service: str) -> str:
    """Find the first timestamp for a service-specific timeline event."""

    for row in rows:
        if row["service"] == service and keyword.lower() in row["event"].lower():
            return row["timestamp"]
    return "not found"


async def nav_analyst(state: IncidentState, tools: SafeToolbox) -> None:
    """Diagnose the upstream NAV/pricing root cause."""

    errors = await tools.call("get_errors", {"service": "nav-service"})
    timeline = await tools.call(
        "get_timeline", {"correlation_id": INCIDENT_CORRELATION_ID}
    )
    recovery_time = _first_timeline_time(timeline, "Failover to", "nav-service")

    state.findings["nav_analyst"] = (
        "The NAV incident began at "
        f"{_first_time(errors, 'response slow')} when the primary BharatData feed "
        "became slow and then timed out. The circuit breaker opened, the NAV "
        "service tried last-good prices, and validation failed for scheme "
        "FF-LC-EQ-001 because prices were stale and one constituent price was "
        "negative (-104.35). The NAV publisher held the intraday NAV, explicitly "
        "warning that downstream services would see NAV_UNAVAILABLE. Recovery "
        f"started at {recovery_time} through SecondaryQuote, "
        "after which validation passed and the delayed NAV was published."
    )


async def order_analyst(state: IncidentState, tools: SafeToolbox) -> None:
    """Diagnose the downstream customer-facing symptoms."""

    errors = await tools.call("get_errors", {"service": "order-service"})
    pii_demo = await tools.call(
        "search_logs",
        {"service": "order-service", "contains": "Full request dump", "level": "DEBUG"},
    )

    held_count = sum("status=HELD reason=NAV_UNAVAILABLE" in line for line in errors)
    first_failure = _first_time(errors, "NAV fetch failed")
    alert_time = _first_time(errors, "ALERT fired")

    state.findings["order_analyst"] = (
        f"The order service first failed to fetch same-day NAV at {first_failure}, "
        "returning NAV_UNAVAILABLE after retries for FF-LC-EQ-001 orders. "
        f"{held_count} redemption/switch orders were held and queued for "
        "reprocessing while /orders/redeem degraded to a 41% 5xx rate and p95 "
        f"latency of 8140 ms. The SEV2 alert fired at {alert_time}. The leaked "
        f"DEBUG request dump was redacted at the tool boundary: {pii_demo[0] if pii_demo else 'no DEBUG leak found'}"
    )


async def correlation_analyst(state: IncidentState, tools: SafeToolbox) -> None:
    """Connect the upstream cause to the downstream symptom by correlation id."""

    trace = await tools.call(
        "trace_correlation", {"correlation_id": INCIDENT_CORRELATION_ID}
    )
    events = trace["events"]
    first_nav = next(item["line"] for item in events if item["service"] == "nav-service")
    first_order = next(item["line"] for item in events if item["service"] == "order-service")
    recovery = next(
        item["line"]
        for item in events
        if item["service"] == "order-service" and "NAV now available" in item["line"]
    )

    state.findings["correlation"] = (
        f"Correlation id {INCIDENT_CORRELATION_ID} links the chain. Upstream, "
        f"the NAV feed warning appears first: {first_nav}. Downstream, the order "
        f"service starts pricing affected same-day orders later: {first_order}. "
        "The NAV service held publication for FF-LC-EQ-001, which directly caused "
        "order-service NAV_UNAVAILABLE failures. Recovery is visible when the "
        f"held queue drains: {recovery}."
    )


def synthesise(state: IncidentState) -> None:
    """Write the RCA using only accumulated specialist findings."""

    state.final_answer = f"""APPROVED RCA DRAFT

Summary:
FundFlow experienced a SEV2 incident for FF-LC-EQ-001 redemptions on 31 Mar 2026. Same-day redemption and switch orders were delayed because the order service could not obtain a valid NAV.

Root cause:
The NAV service lost reliable primary pricing from BharatData. The feed became slow, timed out, and returned a corrupt negative constituent price. NAV validation rejected the affected scheme because of stale price age and the negative price, so the NAV publisher held publication and downstream services saw NAV_UNAVAILABLE.

Impact:
The order service held 9 affected redemption/switch orders, /orders/redeem reached a 41% 5xx rate over 60 seconds, and p95 latency reached 8140 ms. The incident lasted about 13 minutes. Logs state 0 orders were lost and 0 duplicate submissions occurred.

Timeline:
- 14:29:12: BharatData latency warnings and timeout begin in nav-service.
- 14:29:13: Circuit breaker opens for BharatData.
- 14:29:15-14:29:16: NAV validation fails for FF-LC-EQ-001 and publication is held.
- 14:31:57 onward: order-service fails same-day NAV fetches with NAV_UNAVAILABLE and queues affected orders.
- 14:38:20: SEV2 alert fires for high redemption error rate.
- 14:41:01-14:41:02: NAV service fails over to SecondaryQuote, recomputes, validates, and publishes the delayed NAV.
- 14:43:20-14:43:28: order-service drains the held queue and resolves the incident.

Recommended fixes:
1. Raise a vendor incident with BharatData for elevated latency and corrupt price delivery.
2. Add a negative-price pre-filter before NAV validation so corrupt values are isolated earlier.
3. Review the 8000 ms feed timeout and failover policy so SecondaryQuote is used sooner during feed degradation.
4. Add a dashboard that joins NAV publish holds with order-service NAV_UNAVAILABLE errors by correlation id.

Evidence used:
{state.findings.get("nav_analyst", "")}

{state.findings.get("order_analyst", "")}

{state.findings.get("correlation", "")}
"""


def guard_input(state: IncidentState) -> None:
    """Block prompt injection and questions outside the assignment scope."""

    injection_reason = gl.check_injection(state.request)
    if injection_reason:
        state.blocked = True
        state.block_reason = injection_reason
        return

    in_scope, reason = gl.check_scope(state.request)
    if not in_scope:
        state.blocked = True
        state.block_reason = reason


def guard_output(state: IncidentState) -> None:
    """Final redaction pass before human review or user display."""

    state.final_answer = gl.redact_text(state.final_answer)


def human_review(
    state: IncidentState, action: str = "approve", edited_answer: str | None = None
) -> None:
    """Human-in-the-loop gate for approve/edit/reject decisions."""

    if action == "reject":
        state.final_answer = "[RCA rejected by human reviewer.]"
        state.approved = False
    elif action == "edit":
        state.final_answer = edited_answer or state.final_answer
        guard_output(state)
        state.approved = True
    else:
        state.approved = True


async def answer_direct_tool_question(
    state: IncidentState, tools: SafeToolbox
) -> bool:
    """Handle explicit tool-style questions before the full RCA workflow."""

    q = state.request.lower()
    corr_match = re.search(r"corr-[a-z0-9]+", q)

    if "trace" in q and corr_match:
        trace = await tools.call("trace_correlation", {"correlation_id": corr_match.group(0)})
        rows = [
            f"- {item['service']}: {item['line']}"
            for item in trace["events"]
        ]
        state.final_answer = "\n".join(rows)
        return True

    if "error" in q and "order" in q:
        errors = await tools.call("get_errors", {"service": "order-service"})
        state.final_answer = "\n".join(f"- {line}" for line in errors)
        return True

    return False


async def run_incident_copilot(
    question: str,
    *,
    backend: ToolBackend | None = None,
    review_action: str = "approve",
    edited_answer: str | None = None,
) -> IncidentState:
    """Run the complete incident-analysis workflow."""

    state = IncidentState(request=question)
    guard_input(state)
    if state.blocked:
        state.final_answer = (
            f"I can only analyse the FundFlow incident logs ({state.block_reason})."
        )
        state.approved = True
        return state

    tools = SafeToolbox(backend or DirectLogBackend())
    await tools.load()

    handled = await answer_direct_tool_question(state, tools)
    if not handled:
        await nav_analyst(state, tools)
        await order_analyst(state, tools)
        await correlation_analyst(state, tools)
        synthesise(state)

    guard_output(state)
    human_review(state, action=review_action, edited_answer=edited_answer)
    return state


def _select_backend(prefer_mcp: bool) -> ToolBackend:
    """Use MCP when requested, otherwise use the local deterministic backend."""

    if not prefer_mcp:
        return DirectLogBackend()
    return MCPLogBackend()


async def main() -> None:
    parser = argparse.ArgumentParser(description="FundFlow incident-analysis copilot")
    parser.add_argument(
        "question",
        nargs="?",
        default="Summarise the incident and its root cause.",
        help="Question to ask the copilot.",
    )
    parser.add_argument(
        "--mcp",
        action="store_true",
        help="Call tools through the MCP server instead of direct local functions.",
    )
    parser.add_argument(
        "--review-action",
        choices=["approve", "edit", "reject"],
        default="approve",
        help="Simulated human review decision for CLI demos.",
    )
    parser.add_argument(
        "--edited-answer",
        default=None,
        help="Replacement answer used only when --review-action=edit.",
    )
    args = parser.parse_args()

    state = await run_incident_copilot(
        args.question,
        backend=_select_backend(args.mcp),
        review_action=args.review_action,
        edited_answer=args.edited_answer,
    )
    print(state.final_answer)
    print(f"\nHuman review approved: {state.approved}")


if __name__ == "__main__":
    asyncio.run(main())
