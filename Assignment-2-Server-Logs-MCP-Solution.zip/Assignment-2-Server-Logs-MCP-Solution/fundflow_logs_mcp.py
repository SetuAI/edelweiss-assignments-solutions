"""MCP server for the FundFlow incident log assignment.

This module has two jobs:
1. Expose the two provided log files as MCP tools when the `mcp` package is
   installed.
2. Keep the same tool logic available as ordinary Python functions so tests and
   local demos can run even before students install the MCP dependencies.

The logs are fictional training data. They are treated like production logs in
this exercise because one DEBUG line contains customer PII.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

try:
    from mcp.server.fastmcp import FastMCP
except ModuleNotFoundError:  # Allows unit tests to run without MCP installed.
    FastMCP = None  # type: ignore[assignment]


DATA_DIR = Path(os.getenv("FUNDFLOW_LOG_DIR", Path(__file__).parent / "data"))

LOGS: dict[str, Path] = {
    "nav-service": DATA_DIR / "fundflow-nav-service.log",
    "order-service": DATA_DIR / "fundflow-order-service.log",
}

TIMESTAMP = re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})")


def _ensure_service(service: str) -> Path:
    """Return the path for a known service or raise a clear user-facing error."""

    if service not in LOGS:
        available = ", ".join(sorted(LOGS))
        raise ValueError(f"Unknown service '{service}'. Available services: {available}")
    return LOGS[service]


def _read_lines(service: str) -> list[str]:
    """Read one service log as individual lines.

    Keeping file access in one helper makes it easier to add compression,
    remote storage, or caching later without changing every MCP tool.
    """

    path = _ensure_service(service)
    if not path.exists():
        raise FileNotFoundError(f"Log file missing for {service}: {path}")
    return path.read_text(encoding="utf-8").splitlines()


def _timestamp_for_sort(line: str) -> str:
    """Extract the timestamp prefix used for chronological sorting."""

    match = TIMESTAMP.match(line)
    return match.group("ts") if match else line


def list_services() -> list[str]:
    """List the services whose logs are available to the assistant."""

    return sorted(LOGS)


def search_logs(service: str, contains: str = "", level: str = "") -> list[str]:
    """Return log lines filtered by service, substring, and/or log level.

    Parameters
    ----------
    service:
        One of `nav-service` or `order-service`.
    contains:
        Case-insensitive substring filter. Pass an empty string to skip it.
    level:
        Optional log level filter such as INFO, WARN, ERROR, or DEBUG.
    """

    needle = contains.lower().strip()
    required_level = level.upper().strip()

    hits: list[str] = []
    for line in _read_lines(service):
        if required_level and f" {required_level} " not in line:
            continue
        if needle and needle not in line.lower():
            continue
        hits.append(line)
    return hits[:200]


def get_errors(service: str) -> list[str]:
    """Return WARN and ERROR lines, which are usually the fastest incident path."""

    return [
        line
        for line in _read_lines(service)
        if " WARN " in line or " ERROR " in line
    ][:200]


def trace_correlation(correlation_id: str) -> dict[str, Any]:
    """Return all lines across services carrying the same correlation id.

    This is the core distributed-systems diagnostic tool. It lets the agent
    connect the upstream NAV-service failure to downstream order-service impact.
    """

    hits: list[dict[str, str]] = []
    for service in LOGS:
        for line in _read_lines(service):
            if correlation_id in line:
                hits.append({"service": service, "line": line})

    hits.sort(key=lambda item: _timestamp_for_sort(item["line"]))
    return {
        "correlation_id": correlation_id,
        "count": len(hits),
        "events": hits[:300],
    }


def get_timeline(correlation_id: str = "corr-77f31a") -> list[dict[str, str]]:
    """Build a compact timeline for reports and tests.

    This stretch-goal tool converts raw correlated lines into timestamped event
    rows. It keeps the raw log line because SRE reviews need evidence, but the
    consuming agent still redacts tool output before using it.
    """

    trace = trace_correlation(correlation_id)
    rows: list[dict[str, str]] = []
    for event in trace["events"]:
        line = event["line"]
        rows.append(
            {
                "timestamp": _timestamp_for_sort(line),
                "service": event["service"],
                "event": line.split(" - ", 1)[-1],
            }
        )
    return rows


def _build_server() -> Any:
    """Create the FastMCP server and register the tool functions."""

    if FastMCP is None:
        raise RuntimeError(
            "The 'mcp' package is not installed. Run: pip install 'mcp[cli]'"
        )

    server = FastMCP("fundflow-logs")
    server.tool()(list_services)
    server.tool()(search_logs)
    server.tool()(get_errors)
    server.tool()(trace_correlation)
    server.tool()(get_timeline)
    return server


if __name__ == "__main__":
    # stdio is the simplest local transport for an agent that spawns this server.
    _build_server().run(transport="stdio")
