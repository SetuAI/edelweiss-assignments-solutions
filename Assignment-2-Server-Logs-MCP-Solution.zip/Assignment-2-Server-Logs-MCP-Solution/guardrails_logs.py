"""Guardrails for the FundFlow log-analysis assignment.

The most important design choice is that PII redaction is applied to tool
output before it is sent to any model or printed to the user. A prompt can ask a
model not to reveal sensitive data, but a code boundary can prevent the model
from seeing the sensitive data in the first place.
"""

from __future__ import annotations

import json
import re
from typing import Any


# Indian PAN pattern, for example AKLPS4321Q.
PAN = re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")

# Standard email pattern, intentionally broad enough for operational logs.
EMAIL = re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b")

# Unmasked FundFlow folio values. Already-masked values such as FF****2437 are
# allowed to remain because they are not directly identifying.
FOLIO = re.compile(r"\bFF[0-9]{7,}\b")

# The leaked DEBUG line also contains a human name inside an investor object.
INVESTOR_NAME = re.compile(r"name='[^']+'")

INJECTION_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in [
        r"ignore (all |the )?(previous|prior|above) instructions",
        r"reveal your (system )?(prompt|instructions)",
        r"print the raw logs",
        r"show the unredacted logs",
    ]
]

SCOPE_KEYWORDS = {
    "fundflow",
    "incident",
    "log",
    "logs",
    "root cause",
    "rca",
    "error",
    "errors",
    "nav_unavailable",
    "redemption",
    "redeem",
    "order",
    "orders",
    "nav-service",
    "order-service",
    "corr-77f31a",
    "correlation",
    "sev2",
    "price feed",
    "bharatdata",
}


def redact_text(text: str) -> str:
    """Redact sensitive fields from a string of log text."""

    text = PAN.sub("[PAN_REDACTED]", text)
    text = EMAIL.sub("[EMAIL_REDACTED]", text)
    text = FOLIO.sub("[FOLIO_REDACTED]", text)
    text = INVESTOR_NAME.sub("name='[NAME_REDACTED]'", text)
    return text


def redact_output(value: Any) -> Any:
    """Recursively redact strings inside tool outputs.

    MCP tools may return lists, dictionaries, or strings. Redacting recursively
    keeps the guardrail correct even when a tool's return shape changes later.
    """

    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, list):
        return [redact_output(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_output(item) for item in value)
    if isinstance(value, dict):
        return {key: redact_output(item) for key, item in value.items()}
    return value


def redact(value: Any) -> str:
    """Return a redacted string representation suitable for an LLM prompt."""

    safe_value = redact_output(value)
    if isinstance(safe_value, str):
        return safe_value
    return json.dumps(safe_value, indent=2, ensure_ascii=False)


def contains_pii(text: str) -> bool:
    """Detect whether a string still contains known PII patterns."""

    return any(pattern.search(text) for pattern in [PAN, EMAIL, FOLIO])


def assert_no_pii(value: Any) -> None:
    """Fail fast if a redaction regression lets PII through."""

    rendered = redact(value)
    if contains_pii(rendered):
        raise AssertionError("PII was still present after redaction")


def check_injection(query: str) -> str | None:
    """Return a block reason when the user asks the agent to bypass controls."""

    for pattern in INJECTION_PATTERNS:
        if pattern.search(query):
            return "possible prompt-injection attempt"
    return None


def strip_reasoning(text: str) -> str:
    """Remove hidden-chain style tags if a local model emits them."""

    return re.sub(r"<think>.*?</think>", " ", text, flags=re.DOTALL | re.IGNORECASE).strip()


def check_scope(query: str) -> tuple[bool, str]:
    """Keep the assistant focused on the assignment's incident logs.

    This deterministic scope check is deliberately simple for students. In a
    production setup, it can be replaced by a policy classifier, but the final
    authority should still be code rather than a soft prompt instruction.
    """

    q = query.lower()
    if any(keyword in q for keyword in SCOPE_KEYWORDS):
        return True, ""
    return False, "outside the scope of the FundFlow incident logs"
