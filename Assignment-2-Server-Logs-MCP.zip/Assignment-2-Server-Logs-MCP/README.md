# Assignment 2 — Sub-Agentic Incident Analysis over Server Logs (MCP + Guardrails + HITL)

Build an SRE-style copilot that diagnoses a real distributed incident across two service logs,
served through an MCP server, and produces a PII-safe, human-approved root-cause analysis.

## What's in this folder
- `Assignment-2-Reference-Guide.pdf` — the complete assignment: objective, the incident scenario,
  architecture, full step-by-step build (MCP server + agent) with working code, test questions,
  rubric, and submission checklist.
- `data/` — the two correlated logs from the fictional FundFlow mutual-fund platform:
  - `fundflow-nav-service.log`   (ROOT CAUSE — price-feed timeout, negative price, delayed NAV)
  - `fundflow-order-service.log` (SYMPTOMS — redemptions failing with NAV_UNAVAILABLE, SEV2 page)

## The incident (what your agent must uncover)
At 14:29 the NAV service loses its primary price feed and rejects a NAV on a corrupt (negative)
constituent price; NAV publish is delayed ~12 minutes. The order service can't price same-day
redemptions and fails with `NAV_UNAVAILABLE`. Both logs are linked by `corrId=corr-77f31a`.
One DEBUG line in the order log leaks PII (PAN, folio, email) — your redaction guardrail must catch it.

## How to start
1. Read `Assignment-2-Reference-Guide.pdf` end to end.
2. Install deps (`mcp[cli]`, langchain-mcp-adapters, langgraph, langchain-openai; `OPENAI_API_KEY`).
3. Build the MCP server first and test `trace_correlation("corr-77f31a")` returns lines from both logs.
4. Build the agent: MCP-tool-calling sub-agents -> supervisor -> PII redaction -> human review.
5. Validate against the six test questions and complete the submission checklist.

All data is fictional and for training only.
